package Common;

import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Painter.updateAll((Graphics2D) g, Whiteboard.records);
    }
}
