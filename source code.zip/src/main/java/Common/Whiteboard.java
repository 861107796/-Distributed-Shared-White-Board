package Common;

import Client.Client;
import Server.Connection;
import Server.Server;
import org.json.JSONObject;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.concurrent.CopyOnWriteArrayList;

public class Whiteboard {

    private JFrame frm;
    public JTextField txt;
    public JList<String> userList;
    public JTextPane textPane;
    public Painter painter;
    public MyPanel whiteboard;

    public String role;
    public int thickness = 5;
    public String shape = "pencil";
    public Color color = Color.BLACK;

    public static CopyOnWriteArrayList<JSONObject> records = new CopyOnWriteArrayList<>();

    /**
     * Create the application.
     */
    public Whiteboard(String role) {
        this.role = role;
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    initialize();
                    frm.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frm = new JFrame();
        frm.setTitle("Distributed Whiteboard");
        frm.setBounds(100, 100, 800, 800);
        frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frm.getContentPane().setLayout(null);
        frm.setResizable(false);

        JButton btnPencil = new JButton("Pencil");
        btnPencil.setBounds(38, 41, 93, 23);
        btnPencil.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                shape = "pencil";
            }
        });
        frm.getContentPane().add(btnPencil);

        JButton btnLine = new JButton("Line");
        btnLine.setBounds(141, 41, 93, 23);
        btnLine.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                shape = "line";
            }
        });
        frm.getContentPane().add(btnLine);

        JButton btnCircle = new JButton("Circle");
        btnCircle.setBounds(244, 41, 93, 23);
        btnCircle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                shape = "circle";
            }
        });
        frm.getContentPane().add(btnCircle);

        JButton btnOval = new JButton("Oval");
        btnOval.setBounds(347, 41, 93, 23);
        btnOval.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                shape = "oval";
            }
        });
        frm.getContentPane().add(btnOval);

        JButton btnRectangle = new JButton("Rectangle");
        btnRectangle.setBounds(450, 41, 93, 23);
        btnRectangle.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                shape = "rect";
            }
        });
        frm.getContentPane().add(btnRectangle);

        JButton btnText = new JButton("Text");
        btnText.setBounds(656, 41, 93, 23);
        btnText.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                shape = "text";
            }
        });
        frm.getContentPane().add(btnText);

        JButton btnErase = new JButton("Erase");
        btnErase.setBounds(553, 41, 93, 23);
        btnErase.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                shape = "erase";
            }
        });
        frm.getContentPane().add(btnErase);

        JButton btnColor = new JButton("Color");
        btnColor.setBounds(471, 8, 93, 23);
        btnColor.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                color = JColorChooser.showDialog(null, "", color);
            }
        });
        frm.getContentPane().add(btnColor);

        JSlider slider = new JSlider(1, 10);
        slider.addChangeListener(new ChangeListener() {
            public void stateChanged(ChangeEvent arg0) {
                thickness = slider.getValue();
            }
        });
        slider.setBounds(574, 10, 200, 26);
        frm.getContentPane().add(slider);

        whiteboard = new MyPanel();
        whiteboard.setBounds(10, 100, 600, 600);
        whiteboard.setBackground(Color.WHITE);
        frm.getContentPane().add(whiteboard);

        painter = new Painter(this);
        whiteboard.addMouseListener(painter);
        whiteboard.addMouseMotionListener(painter);

        txt = new JTextField();
        txt.setBounds(620, 650, 154, 21);
        frm.getContentPane().add(txt);
        txt.setColumns(10);

        JButton btnSend = new JButton("Send");
        btnSend.setBounds(651, 677, 93, 23);
        btnSend.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (role.equals("server")) {
                    String chatMsg = Server.username + ":" + txt.getText();
                    JSONObject msg = new JSONObject();
                    msg.put("command", Constants.CHAT);
                    msg.put("msg", chatMsg);
                    Server.broadcast(msg.toString());
                    textPane.setText(textPane.getText() + "\n" + chatMsg);
                } else {
                    String chatMsg = Client.username + ":" + txt.getText();
                    JSONObject msg = new JSONObject();
                    msg.put("command", Constants.CHAT);
                    msg.put("msg", chatMsg);
                    Client.send(msg.toString());
                    textPane.setText(textPane.getText() + "\n" + chatMsg);
                }
            }
        });
        frm.getContentPane().add(btnSend);

        userList = new JList<>();
        userList.setBounds(617, 100, 157, 139);
        frm.getContentPane().add(userList);

        textPane = new JTextPane();
        textPane.setEditable(false);
        textPane.setBounds(620, 291, 154, 343);
        frm.getContentPane().add(textPane);

        // Below are Server only
        if (role.equals("client")) {
            return;
        }

        JMenuBar menuBar = new JMenuBar();
        menuBar.setBounds(0, 0, 105, 21);
        JMenu menu = new JMenu("File");
        JMenuItem menuItem1 = new JMenuItem("New");
        menuItem1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                whiteboard.removeAll();
                whiteboard.updateUI();
                records.clear();
                JSONObject msg = new JSONObject();
                msg.put("command", Constants.NEW_BOARD);
                Server.broadcast(msg.toString());
            }
        });
        JMenuItem menuItem2 = new JMenuItem("Save");
        menuItem2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String path = JOptionPane.showInputDialog("Save path: ", "./whiteboard");

                try {
                    PrintWriter printWriter = new PrintWriter(new FileOutputStream(path));
                    for (JSONObject record : records) {
                        printWriter.println(record);
                    }
                    printWriter.flush();
                    printWriter.close();

                    BufferedImage bufferedImage = new BufferedImage(600, 600, BufferedImage.TYPE_INT_RGB);
                    Graphics2D g = bufferedImage.createGraphics();
                    g.setColor(Color.white);
                    g.fillRect(0, 0, 600, 600);
                    painter.save(g, records);
                    ImageIO.write(bufferedImage, "JPEG", new File(path + ".jpg"));
                    bufferedImage.flush();
                } catch (Exception ee) {
                    ee.printStackTrace();
                    JOptionPane.showMessageDialog(null, "save error");
                }
            }
        });
        JMenuItem menuItem3 = new JMenuItem("Load");
        menuItem3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String path = JOptionPane.showInputDialog("Load path: ", "./whiteboard");
                    Scanner s = new Scanner(new FileInputStream(path));

                    whiteboard.removeAll();
                    whiteboard.updateUI();
                    records.clear();
                    JSONObject msg = new JSONObject();
                    msg.put("command", Constants.NEW_BOARD);
                    Server.broadcast(msg.toString());

                    while (s.hasNextLine()) {
                        JSONObject object = new JSONObject(s.nextLine());
                        records.add(object);
                        object.put("command", Constants.DRAW);
                        Server.broadcast(object.toString());
                    }
                    whiteboard.repaint(); //
                } catch (Exception ee) {
                    ee.printStackTrace();
                    JOptionPane.showMessageDialog(null, "load error");
                }
            }
        });
        JMenuItem menuItem4 = new JMenuItem("Exit");
        menuItem4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
        menu.add(menuItem1);
        menu.addSeparator();
        menu.add(menuItem2);
        menu.addSeparator();
        menu.add(menuItem3);
        menu.addSeparator();
        menu.add(menuItem4);
        menuBar.add(menu);
        frm.setJMenuBar(menuBar);

        JButton btnKickOut = new JButton("Kick Out");
        btnKickOut.setBounds(651, 249, 93, 23);
        btnKickOut.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                for (Connection c : Server.connections) {
                    if (c.username.equals(userList.getSelectedValue())) {
                        JSONObject kick = new JSONObject();
                        kick.put("command", Constants.KICK);
                        c.send(kick.toString());
                        Server.connections.remove(c);
                    }
                }
                JSONObject userList = new JSONObject();
                userList.put("command", Constants.USERS);
                String users = Server.username;
                for (Connection connection : Server.connections) {
                    users += ",";
                    users += connection.username;
                }
                userList.put("users", users);
                Server.broadcast(userList.toString());
            }
        });
        frm.getContentPane().add(btnKickOut);

    }
}
