package Common;

import Client.Client;
import Server.Server;
import org.json.JSONObject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Painter implements MouseListener, MouseMotionListener {
    Whiteboard w;
    Graphics2D g;
    int startX, startY, endX, endY;
    String inputText = "";

    public Painter(Whiteboard w) {
        this.w = w;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // no need to implement
    }

    @Override
    public void mousePressed(MouseEvent e) {
        startX = e.getX();
        startY = e.getY();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        endX = e.getX();
        endY = e.getY();
        if (this.w.shape.equals("text")) {
            inputText = JOptionPane.showInputDialog("Input your text here:", "text");
        }
        if (this.w.shape.equals("erase")) {
            draw(w.shape, startX, startY, endX, endY, w.thickness, Color.WHITE, inputText);
        } else {
            draw(w.shape, startX, startY, endX, endY, w.thickness, w.color, inputText);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        // no need to implement
    }

    @Override
    public void mouseExited(MouseEvent e) {
        // no need to implement
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if (this.w.shape.equals("pencil") || this.w.shape.equals("erase")) {
            endX = e.getX();
            endY = e.getY();
            if (this.w.shape.equals("pencil")) {
                draw(w.shape, startX, startY, endX, endY, w.thickness, w.color, inputText);
            } else {
                draw(w.shape, startX, startY, endX, endY, w.thickness, Color.WHITE, inputText);
            }
            startX = endX;
            startY = endY;
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        // no need to implement
    }

    public void draw(String shape, int startX, int startY, int endX, int endY, int thickness, Color color, String text) {
        if (shape == null) {
            return;
        }

        // update whiteboard
        g = (Graphics2D) w.whiteboard.getGraphics();
        g.setStroke(new BasicStroke(w.thickness));
        g.setColor(color);
        switch (shape) {
            case "pencil", "line", "erase" -> g.drawLine(startX, startY, endX, endY);
            case "circle" -> {
                int d = Math.min(Math.abs(startX - endX), Math.abs(startY - endY));
                g.drawOval(startX, startY, d, d);
            }
            case "oval" -> g.drawOval(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY));
            case "rect" -> g.drawRect(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY));
            case "text" -> g.drawString(text, startX, startY);
        }

        // send by connection
        JSONObject msg = new JSONObject();
        msg.put("command", Constants.DRAW);
        msg.put("shape", shape);
        msg.put("startX", startX);
        msg.put("startY", startY);
        msg.put("endX", endX);
        msg.put("endY", endY);
        msg.put("thickness", thickness);
        msg.put("color", color);
        msg.put("text", text);
        try {
            if (w.role.equals("server")) {
                Server.broadcast(msg.toString());
            } else {
                Client.send(msg.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        Whiteboard.records.add(msg);
    }

    // only update whiteboard, no message sent
    public void update(JSONObject msg) {
        if (msg == null) {
            return;
        }
        String shape = msg.getString("shape");
        int startX = msg.getInt("startX");
        int startY = msg.getInt("startY");
        int endX = msg.getInt("endX");
        int endY = msg.getInt("endY");
        int thickness = msg.getInt("thickness");
        String text = msg.getString("text");

        String colorStr = msg.get("color").toString();
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(colorStr);
        int[] rgb = new int[3];
        int i = 0;
        while (m.find()) {
            rgb[i] = Integer.parseInt(m.group());
            i++;
        }
        Color color = new Color(rgb[0], rgb[1], rgb[2]);

        g = (Graphics2D) w.whiteboard.getGraphics();
        g.setStroke(new BasicStroke(thickness));
        g.setColor(color);

        switch (shape) {
            case "pencil", "line", "erase" -> g.drawLine(startX, startY, endX, endY);
            case "circle" -> {
                int d = Math.min(Math.abs(startX - endX), Math.abs(startY - endY));
                g.drawOval(startX, startY, d, d);
            }
            case "oval" -> g.drawOval(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY));
            case "rect" -> g.drawRect(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY));
            case "text" -> g.drawString(text, startX, startY);
        }

    }

    public void update(Graphics2D g, JSONObject msg) {
        if (msg == null) {
            return;
        }
        String shape = msg.getString("shape");
        int startX = msg.getInt("startX");
        int startY = msg.getInt("startY");
        int endX = msg.getInt("endX");
        int endY = msg.getInt("endY");
        int thickness = msg.getInt("thickness");
        String text = msg.getString("text");

        String colorStr = msg.get("color").toString();
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(colorStr);
        int[] rgb = new int[3];
        int i = 0;
        while (m.find()) {
            rgb[i] = Integer.parseInt(m.group());
            i++;
        }
        Color color = new Color(rgb[0], rgb[1], rgb[2]);

        g.setStroke(new BasicStroke(thickness));
        g.setColor(color);

        switch (shape) {
            case "pencil", "line", "erase" -> g.drawLine(startX, startY, endX, endY);
            case "circle" -> {
                int d = Math.min(Math.abs(startX - endX), Math.abs(startY - endY));
                g.drawOval(startX, startY, d, d);
            }
            case "oval" -> g.drawOval(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY));
            case "rect" -> g.drawRect(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY));
            case "text" -> g.drawString(text, startX, startY);
        }

        Whiteboard.records.add(msg);
    }

    public static void repaint(Graphics2D g, JSONObject msg) {
        if (msg == null) {
            return;
        }
        String shape = msg.getString("shape");
        int startX = msg.getInt("startX");
        int startY = msg.getInt("startY");
        int endX = msg.getInt("endX");
        int endY = msg.getInt("endY");
        int thickness = msg.getInt("thickness");
        String text = msg.getString("text");

        String colorStr = msg.get("color").toString();
        Pattern p = Pattern.compile("\\d+");
        Matcher m = p.matcher(colorStr);
        int[] rgb = new int[3];
        int i = 0;
        while (m.find()) {
            rgb[i] = Integer.parseInt(m.group());
            i++;
        }
        Color color = new Color(rgb[0], rgb[1], rgb[2]);

        g.setStroke(new BasicStroke(thickness));
        g.setColor(color);

        switch (shape) {
            case "pencil", "line", "erase" -> g.drawLine(startX, startY, endX, endY);
            case "circle" -> {
                int d = Math.min(Math.abs(startX - endX), Math.abs(startY - endY));
                g.drawOval(startX, startY, d, d);
            }
            case "oval" -> g.drawOval(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY));
            case "rect" -> g.drawRect(startX, startY, Math.abs(startX - endX), Math.abs(startY - endY));
            case "text" -> g.drawString(text, startX, startY);
        }
    }

    public static void updateAll(Graphics2D g, CopyOnWriteArrayList<JSONObject> records) {
        for (JSONObject record : records) {
            repaint(g, record);
        }
    }


    public void save(Graphics2D g, CopyOnWriteArrayList<JSONObject> records) {
        for (JSONObject record : records) {
            update(g, record);
        }
    }
}

