package Common;

public class Constants {
    // CMD
    public static final String DRAW = "DRAW";
    public static final String NEW_BOARD = "NEW_BOARD";
    public static final String CHAT = "CHAT";
    public static final String USERS = "USERS";
    public static final String NEW_USER = "NEW_USER";
    public static final String ACK = "ACK";
    public static final String NAK = "NAK";
    public static final String KICK = "KICK";

}
