package Server;

import Common.Whiteboard;

import javax.swing.*;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.CopyOnWriteArrayList;

public class Server {
    public static String username = "Host";
    public static String ip = "127.0.0.1";
    public static String port = "8888";
    public static ServerSocket ss;

    public static CopyOnWriteArrayList<Connection> connections = new CopyOnWriteArrayList<>(); // for concurrent



    public static void main(String[] args) throws IOException {
        if (args.length >= 3) {
            ip = args[0];
            port = args[1];
            username = args[2];
        }
        username = JOptionPane.showInputDialog("Input your username: ", username);

        // start Whiteboard GUI
        Whiteboard w = new Whiteboard("server");

        // accept client connections
        ss = new ServerSocket(Integer.parseInt(port));
        while (!ss.isClosed()) {
            Socket s = ss.accept();
            Connection c = new Connection(s, w); // Thread per connection
            connections.add(c);
            c.start();
        }
    }

    public static void broadcast(String msg) {
        // System.out.println("broadcast: " + msg);
        try {
            for (Connection connection : connections) {
                // System.out.println(connection.username);
                connection.o.writeUTF(msg);
                connection.o.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void repost(String msg, String sender) {
        // System.out.println(sender + " repost: " + msg);
        try {
            for (Connection connection : connections) {
                if (connection.username.equals(sender)) {
                    continue;
                }
                // System.out.println(connection.username);
                connection.o.writeUTF(msg);
                connection.o.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}