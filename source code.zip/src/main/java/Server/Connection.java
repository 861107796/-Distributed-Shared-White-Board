package Server;

import Common.Constants;
import Common.Whiteboard;
import org.json.JSONObject;

import javax.swing.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Connection extends Thread {
    Socket s;
    Whiteboard w;
    DataInputStream i;
    DataOutputStream o;

    public String username;


    public Connection(Socket s, Whiteboard w) throws IOException {
        this.s = s;
        this.w = w;
        i = new DataInputStream(this.s.getInputStream());
        o = new DataOutputStream(this.s.getOutputStream());
    }

    @Override
    public void run() {
        while (true) {
            try {
                JSONObject input = new JSONObject(i.readUTF());
                // System.out.println("in: " + input);
                switch (input.get("command").toString()) {
                    case Constants.NEW_USER -> {
                        username = input.getString("username");
                        if (JOptionPane.showConfirmDialog(null, username + " is waiting your approval", "", JOptionPane.YES_NO_CANCEL_OPTION) == JOptionPane.OK_OPTION) {
                            JSONObject ack = new JSONObject();
                            ack.put("command", Constants.ACK);
                            send(ack.toString());

                            JSONObject userList = new JSONObject();
                            userList.put("command", Constants.USERS);
                            String users = Server.username;
                            for (Connection connection : Server.connections) {
                                users += ",";
                                users += connection.username;
                            }
                            w.userList.setListData(users.split(","));
                            userList.put("users", users);
                            Server.broadcast(userList.toString());

                            for (JSONObject record : Whiteboard.records) {
                                record.put("command", Constants.DRAW);
                                send(record.toString());
                            }
                        } else {
                            JSONObject nak = new JSONObject();
                            nak.put("command", Constants.NAK);
                            send(nak.toString());
                            Server.connections.remove(this);
                        }
                    }
                    case Constants.DRAW -> {
                        w.painter.update(input);
                        Whiteboard.records.add(input);
                        Server.repost(input.toString(), username);
                    }
                    case Constants.CHAT -> {
                        w.textPane.setText(w.textPane.getText() + "\n" + input.getString("msg"));
                        Server.repost(input.toString(), username);
                    }
                }

            } catch (IOException e) { // user leave
                Server.connections.remove(this);

                JSONObject msg = new JSONObject();
                msg.put("command", Constants.USERS);
                String users = Server.username;
                for (Connection connection : Server.connections) {
                    users += ",";
                    users += connection.username;
                }
                w.userList.setListData(users.split(","));
                msg.put("users", users);
                Server.broadcast(msg.toString());

                JOptionPane.showMessageDialog(null, this.username + " quits.");
                break;
            } catch (Exception e2) { // unhandled error
                e2.printStackTrace();
                break;
            }
        }
    }

    public void send(String msg) {
        try {
            o.writeUTF(msg);
            o.flush();
            // System.out.println("out: " + msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
