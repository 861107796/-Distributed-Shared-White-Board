package Client;

import Common.Constants;
import Common.Whiteboard;
import org.json.JSONObject;

import javax.swing.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class Client {

    static Socket s;
    static DataInputStream i;
    static DataOutputStream o;
    static Whiteboard w;
    public static String username = "Guest";
    public static String ip = "127.0.0.1";
    public static String port = "8888";

    public static void main(String[] args) {
        if (args.length >= 3) {
            ip = args[0];
            port = args[1];
            username = args[2];
        }
        username = JOptionPane.showInputDialog("Input your username: ", username);

        try {
            // connect with server
            s = new Socket(ip, Integer.parseInt(port));
            i = new DataInputStream(s.getInputStream());
            o = new DataOutputStream(s.getOutputStream());
            JSONObject join = new JSONObject();
            join.put("command", Constants.NEW_USER);
            join.put("username", username);
            send(join.toString());

            // accept message from server
            while (!s.isClosed()) {
                JSONObject input = new JSONObject(i.readUTF());
                // System.out.println("in: " + input);
                switch (input.getString("command")) {
                    case Constants.ACK -> {
                        w = new Whiteboard("client"); // start Whiteboard GUI
                        Thread.sleep(1000); // time for init GUI
                    }
                    case Constants.NAK -> {
                        JOptionPane.showMessageDialog(null, "Server rejected.");
                        System.exit(0);
                    }
                    case Constants.KICK -> {
                        JOptionPane.showMessageDialog(null, "You have been kicked.");
                        System.exit(0);
                    }
                    case Constants.USERS -> w.userList.setListData(input.getString("users").split(","));
                    case Constants.DRAW -> w.painter.update(input);
                    case Constants.CHAT -> w.textPane.setText(w.textPane.getText() + "\n" + input.getString("msg"));
                    case Constants.NEW_BOARD -> {
                        w.whiteboard.removeAll();
                        w.whiteboard.updateUI();
                        Whiteboard.records.clear();
                        w.whiteboard.repaint();
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "server disconnected.");
            System.exit(0);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static void send(String msg) {
        try {
            o.writeUTF(msg);
            o.flush();
            // System.out.println("out: " + msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
